# The Green Grow Shop

Sitio web de ventas en línea. Desarrollado para GitHub Pages.

## Cómo subir a GitHub

1. Crea un repositorio llamado `the-green-grow-shop`.
2. Sube estos archivos (`index.html`, `.nojekyll`, etc.).
3. Entra en **Settings > Pages**, selecciona:
   - Branch: `main`
   - Folder: `/root`
4. Espera unos segundos y accede en:  
   `https://github.io/the-green-grow-shop/` *(ajusta con tu usuario de GitHub)*
